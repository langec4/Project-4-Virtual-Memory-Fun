#ifndef _PSTAT_H_
#define _PSTAT_H_

#include "param.h"

struct pstat {
    int inuse[NPROC];   // Process in use (1) or not (0)
    int tickets[NPROC]; // Tickets each process has
    int pid[NPROC];     // Process ID
    int ticks[NPROC];   // Number of ticks that have been used
};

#endif 
